#include "SEEKFREE_TSL1401.h"
#include "zf_adc.h"
#include "A_CCD.h"


void ccd_collect(void)
{
    uint8 i = 0;
    
    CCD_CLK(1);CCD_SI(0);CCD_CLK(0);CCD_SI(1);CCD_CLK(1); CCD_SI(0);
    
    for(i=0;i<128;i++)
    {
		CCD_CLK(0);  
		CCD1.ccd_data[i]  = adc_once(ADC_P05, ADC_12BIT); 
        CCD2.ccd_data[i]  = adc_once(ADC_P03, ADC_12BIT);
		CCD_CLK(1); 
    }

}
