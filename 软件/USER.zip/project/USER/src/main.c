/*    	ÿ��һ�� �ù�ʡ��             ����ΰ� �ȹ�����        */
/* \\ \\ \\ \\ \\ \\ \\ || || || || || || // // // // // // // //
\\ \\ \\ \\ \\ \\ \\        _ooOoo_          // // // // // // //
\\ \\ \\ \\ \\ \\          o8888888o            // // // // // //
\\ \\ \\ \\ \\             88" . "88               // // // // //
\\ \\ \\ \\                (| -_- |)                  // // // //
\\ \\ \\                   O\  =  /O                     // // //
\\ \\                   ____/`---'\____                     // //
\\                    .'  \\|     |//  `.                      //
==                   /  \\|||  :  |||//  \                     ==
==                  /  _||||| -:- |||||-  \                    ==
==                  |   | \\\  -  /// |   |                    ==
==                  | \_|  ''\---/''  |   |                    ==
==                  \  .-\__  `-`  ___/-. /                    ==
==                ___`. .'  /--.--\  `. . ___                  ==
==              ."" '<  `.___\_<|>_/___.'  >'"".               ==
==            | | :  `- \`.;`\ _ /`;.`/ - ` : | |              \\
//            \  \ `-.   \_ __\ /__ _/   .-` /  /              \\
//      ========`-.____`-.___\_____/___.-`____.-'========      \\
//                           `=---='                           \\
// //   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  \\ \\
// // //      ���汣��      ����BUG      �����޸�        \\ \\ \\
// // // // // // || || || || || || || || || || \\ \\ \\ \\ \\ */
#include "headfile.h"


void seekfree_data()
{
    seekfree_assistant_oscilloscope_data.dat[7] =  Car_Mode;

    seekfree_assistant_oscilloscope_data.dat[0] =  price.output_val;
    seekfree_assistant_oscilloscope_data.dat[1] =  IMUdata.GYRO_Z;
    seekfree_assistant_oscilloscope_data.dat[2] =  Servo.output_val;
    
   // seekfree_assistant_oscilloscope_data.dat[1] = ring_num;
    
    seekfree_assistant_oscilloscope_data.channel_num = 8;
    seekfree_assistant_oscilloscope_send(&seekfree_assistant_oscilloscope_data); // ��������ʾ��������
}


void Is_close()
{
    static cnt = 0;
    if((CCD1.find_R == 'N'&&CCD1.find_L == 'N')/*||(CCD2.find_R == 'N'&&CCD2.find_L == 'N')*/)cnt++;
    else cnt = 0;
    if(cnt > 30)
    {
        Car_Mode = Stops;
        esc_pwm_value = 0;
    }
}
void main()
{
   
    Car_Init();
    pit_timer_ms(TIM_4, TIM4_ISR);				//CCD 
    EnableGlobalIRQ(); //��������ж�
    BUZZ_time = 20;//����������
    mypid_init();
   
    while(Car_Mode == Stops)
    {
         //Step1.flag = 1;
        Image_Send1(CCD2.normalized_data, CCD1.normalized_data);//ͼ����
        Key_Proc();
        UI_Disp();

    }
    if(!SW2)EepromWrite();
    for (;;)
    {

        if(uwTick >= 3)
        {
            uwTick = 0;
            if(Car_Mode != Zebra)
            seekfree_data();//����ʾ����
            RGBR = Car_Mode;
            RGB_LED();
            if(Car_Mode == Normals&&Car_Mode == Ramps)
            Is_close(); 
            
         if(!SW1)//Ϊ0�ǲ���
         {
           Key_Proc();
           UI_Disp(); 
           Image_Send1(CCD2.normalized_data, CCD1.normalized_data);//ͼ����             
          } 
        }

    }

}



