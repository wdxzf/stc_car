#include "A_Is.h"
CarMode Car_Mode = Stops;

//Ԫ��״̬ Ԫ������ Ԫ�����о���

element LRing = {0,2,0};//��
element RRing = {0,2,0};//�һ�
element ramps = {0,2, 0}; //б��
element zebra = {0, 1, 5000}; //������
uint8 Normals_flag = 0;
uint8 ring_seq[8] = {0,0,0,0,0,0,0,0}; //0�� 1�һ�
uint8 ring_num = 7;
uint8 RSeq = 10;

int16 Speed_target_val_LRING[4] = {290,320,260,350};//ԤԲ����Բ��//Բ����//��Բ��//������
int16 Speed_target_val_RRING[4] = {280,300,260,300};//ԤԲ����Բ��//Բ����//��Բ��//������
int16 Speed_target_val_Ramps[3] = {340,300,360};    //Ԥ����//����//�¶�

int16 Normals_high_Speed = 330;//340
int16 Normals_low_speed = 310;//290
int16 straight_high_Speed = 430;//430
int16 straight_acc = 50;

uint8 Zebra_cnt = 20; //������ʱ��

uint8 Element_go = Zebra;
int16 Element_go_speed = 0;

uint8 Element_go_1 = Zebra;
int16 Element_go_1_speed = 0;

float Ring_lenght = 0;

int16 Element_go_3_speed = 0;
void is_Handl() /* �ϰ��ж� */
{
    // �ж��Ҳ��Ƿ����ϰ�
    if ((-CCD2.right_col + CCD2.right[0] > 3) && 
        (-CCD2.right_col + CCD2.right[1] > 3) && 
        (-CCD2.right_col + CCD2.right[2] > 3) && 
        (-CCD2.right_col + CCD2.right[3] > 3) &&
        func_abs(CCD2.left_col - CCD2.left[0]) < 3 && 
        CCD2.wides < 25)
    {
        if (CCD2.find_R == 'Y' && CCD2.find_L == 'Y')
        {
            BUZZ_time = 100;
        }
    }

    // �ж�����Ƿ����ϰ�
    if ((CCD2.left_col - CCD2.left[0] > 3) && 
        (CCD2.left_col - CCD2.left[1] > 3) && 
        (CCD2.left_col - CCD2.left[2] > 3) && 
        (CCD2.left_col - CCD2.left[3] > 3) &&
        func_abs(CCD2.right_col - CCD2.right[0]) < 3 && 
        CCD2.wides < 25)
    {
        if (CCD2.find_R == 'Y' && CCD2.find_L == 'Y')
        {
            BUZZ_time = 100;
        }
    }
}

void Handl_Handl()/*�ϰ�����*/
{
   
}
void is_Ramps()/*б���ж�*/
{
    static uint8 cnt = 0;
    uint16 val;

    val = adc_once(ADC_P14, ADC_12BIT);
    val = (uint16)((8 * adc_once(ADC_P14, ADC_12BIT) + val * 2) * 0.1);
    
    cnt = (val > 950) ? cnt + 1 : 0;

        if(cnt > 10 && CCD2.wides > 36 && CCD2.wides - CCD2.wide[0] > 0 /*|| (IMUdata.Pitch < -1200 && val > 1310)*/)
        {
            Car_Mode = Ramps;
            BUZZ_time = 1;
        }

}
void Ramps_Handle()/*б�´���*/
{
    uint16 val;

    val = adc_once(ADC_P14, ADC_12BIT);
    val = (uint16)((8 * adc_once(ADC_P14, ADC_12BIT) + val * 2) * 0.1);
    

    switch(ramps.flag)
    {
     case 0 ://Ԥ����
         Step1.flag = 1;
        if(val < 300) ramps.flag++;//�����ж�
        break;
    case 1: //����
        if(val > 800&&IMUdata.Pitch > 200) ramps.flag++;//�����ж�
        break;
    case 2://����
         if((val < 500) && func_abs(IMUdata.Pitch) < 800 && Step1.Lenth > 150)//�����ж�
        {
            Car_Mode = Normals; 
            Step1.flag = 0 ;
            ramps.num--;
            ramps.flag = 0;
        }
        break;
    }
    if(Step1.Lenth > 300)
    {
            Car_Mode = Normals; 
            Step1.flag = 0 ;
            ramps.num--;
            ramps.flag = 0;
    }
    Servo.ek  = CCD1.centres - Center;//����ѭ��
    if(func_abs(Servo.ek - Servo.ek1[0]) > 10 ) Servo.ek = Servo.ek1[0];
    
    Speed.target_val = Speed_target_val_Ramps[ramps.flag];
    RGBL = ramps.flag ;
 
}
void is_Zebra()/*�������ж�*/
{
    uint8 val = 0;
    uint8 i;

       for(i = 30; i < 94; i++)
      {
        if(func_abs(CCD1.normalized_data[i] - CCD1.normalized_data[i + 1]) > 15) val++;
      }
      if(val > 12) {Car_Mode = Zebra;}


}
void Zebra_Handle()/*�����ߴ���*/
{
    if(zebra.flag == 0)
    {
        if(Zebra_cnt > 0)Zebra_cnt--; 
        else zebra.flag++;       
    }
    
   if(zebra.flag == 1)
    {
       pwm_duty(ESC_PWMR,  0);//4000
       pwm_duty(ESC_PWML,  0);//��
    }
    Servo.ek  = CCD1.centres - Center;
}

void is_RRING()/*�һ��ж�*/
{
    static uint8 cnt = 0;

    if(CCD1.find_R == 'N' && CCD1.find_L == 'Y' && CCD1.right_col < 100/*&& CCD2.find_L == 'Y'*/)
    {
        cnt++;
        if(cnt > 15)
        {
            Car_Mode = RRING;
            Ring_lenght = lenght;
            cnt = 0;
            Speed.target_val = Speed_target_val_RRING[RRing.flag]; 
        }

    }
    else
    {
        cnt = 0;
    }
}
void RRING_Handle()/*�һ�����*/
{

    switch(RRing.flag)
    {
    case 0://ԤԲ���ж�
        //��Ѳ��
        Servo.ek  = CCD1.left_col + CCDWIde1 - Center;

        if(CCD1.find_R == 'Y' && CCD1.find_L == 'Y'  && CCD1 .wides < 50)
        {
            RRing.flag++;
        }
        break;
    case 1: // ��Ѳ��
        Servo.ek  = (CCD1.right_col - CCDWIde1 - Center- CCD1 .wides / 25);
        IMUdata.flag = 1; // �������ֱ�־λ

        if (IMUdata.Yaw >= 50  && CCD1.find_L == 'Y')
        {
            Speed.target_val = Speed_target_val_RRING[RRing.flag]; 
            RRing.flag ++;
        }
        else if(IMUdata.Yaw >= 65)
        {
            Speed.target_val = Speed_target_val_RRING[RRing.flag]; 
            RRing.flag ++;
            
        }
        break;
    case 2: // ����Ѳ��
       
        Servo.ek  = CCD1.left_col + CCDWIde1 - Center + 2; 
        //Servo.ek  = CCD1.centres - Center; 
    if (IMUdata.Yaw >= 250 /*&& (CCD1.find_R == 'N' && CCD1.find_L == 'N')*/)
        {
            Speed.target_val = Speed_target_val_RRING[RRing.flag]; 
            RRing.flag ++;

        }
        break;
    case 3:
        // ������һ��ƫ��
           Servo.ek  = Servo.ek1[0];
           if (IMUdata.Yaw >= 300&&CCD1.find_L == 'Y')
        {
            Speed.target_val = Speed_target_val_RRING[RRing.flag]; 
            IMUdata.flag = 0U; // �رջ��ֱ�־λ
            RRing.flag ++;
            
        }
        break;
    case 4:
      Servo.ek  = CCD1.left_col + CCDWIde1 - Center; //��Ѳ��
        Step1.flag = 1; // ���������־λ
        if (Step1.Lenth > 110) // Բ������
        {
            ring_num--;
            RRing.num--;
            RRing.flag = 0;
            Car_Mode = Normals;
            Step1.flag = 0; // �رվ����־λ
        }
        break;
    }
    if(lenght - Ring_lenght > 1000 && RRing.flag < 4)
    {
            RRing.flag = 0;
            Car_Mode = Normals;
    }
    RGBL = RRing.flag ;

}
void is_LRING()/*���ж�*/
{
    static uint8 cnt = 0;

    if(CCD1.find_L == 'N' && CCD1.find_R == 'Y' && CCD1.left_col > 30)
    {
        cnt++;
        if(cnt > 15)
        {
            Car_Mode = LRING;
            Ring_lenght = lenght;
            cnt = 0;
            Speed.target_val = Speed_target_val_LRING[LRing.flag]; 
        }

    }
    else
    {
        cnt = 0;
    }
}
void LRING_Handle()/*�󻷴���*/
{
    switch (LRing.flag)
    {
    case 0: // ԤԲ���ж�
        // ��Ѳ��
        Servo.ek  = (CCD1.right_col - CCDWIde1 - Center);
        
         if(CCD1.find_R == 'Y' && CCD1.find_L == 'Y' /*&& CCD1 .wides < 50*/)
        {
            LRing.flag ++;
        } 
        break;
    case 1://��Բ��
        // ��Ѳ��
    
        Servo.ek  = CCD1.left_col + CCDWIde1 - Center + CCD1 .wides / 25;
        
        IMUdata.flag = 1U; // �������ֱ�־λ

        if (IMUdata.Yaw <= -50 && CCD1.find_R == 'Y')
        {
             Speed.target_val = Speed_target_val_LRING[LRing.flag]; 
            LRing.flag ++;
           
        }
        else if(IMUdata.Yaw <= -65)
        {
            Speed.target_val = Speed_target_val_LRING[LRing.flag];  
            LRing.flag++;
        }

        break;
    case 2:
        // ����Ѱ��
        Servo.ek  = CCD1.right_col - CCDWIde1 - Center - 2;
     //Servo.ek  = CCD1.centres - Center; 
        if (IMUdata.Yaw <= -240/* && (CCD1.find_R == 'N' && CCD1.find_L == 'N')*/)
        {
             Speed.target_val = Speed_target_val_LRING[LRing.flag]; 
            LRing.flag ++;
           
        }
        break;
    case 3:
        // ������һ��ƫ��
   // if(CCD1.find_L == 'Y') Servo.ek  = CCD1.left_col + CCDWIde1 - Center;
       Servo.ek  = Servo.ek1[0];
        
        if (IMUdata.Yaw <= -300 && CCD1.find_R == 'Y')
        {
             Speed.target_val = Speed_target_val_LRING[LRing.flag]; 
            LRing.flag ++;
        }
//        else if(IMUdata.Yaw >= 350)
//        {

//            LRing.flag ++;
//        }

        break;

    case 4:
        // ��Ѳ��
        Servo.ek  = (CCD1.right_col - CCDWIde1 - Center);
        IMUdata.flag = 0; // �رջ��ֱ�־λ
        Step1.flag = 1; // ���������־λ
        if (Step1.Lenth > 110) // Բ������
        {
            LRing.flag = 0U;
            Car_Mode = Normals;
            LRing.num--;
            ring_num--;
            Step1.flag = 0U;
        }
        break;

    default:
        Car_Mode = Stops;
        break;
    }
     if(lenght - Ring_lenght > 1000 && RRing.flag < 4)
    {
            LRing.flag = 0;
            Car_Mode = Normals;
    }
   
    RGBL = LRing.flag ;
}
void UpdateSpeed(uint8 element, int16 element_speed)//��Ԫ��֮��ļӼ���
{
    switch (element)
    {
        case Ramps:
            if (ramps.num == 0) Speed.target_val += element_speed;
            break;
        case LRING:
            if (LRing.num == 0) Speed.target_val += element_speed;
            break;
        case RRING:
            if (RRing.num == 0) Speed.target_val += element_speed;
            break;
        case Zebra:
            if (zebra.num == 0) Speed.target_val += element_speed;
            break;
    }
}
void Normals_Speed()
{
    int16 erro[5];
    static uint16 cnt = 0;

    // �������洢�������У������μ���
    erro[0] = func_abs(CCD1.centres - Center); 
    erro[1] = func_abs(CCD2.centres - Center);
    erro[2] = func_abs(CCD2.centres - CCD1.centres);
    erro[3] = func_abs(CCD1.wides - 2 * CCDWIde1);
    erro[4] = func_abs(CCD2.wides - 2 * CCDWIde2);

    // ����Ŀ���ٶ�
    Speed.target_val = Normals_high_Speed - ((Normals_high_Speed - Normals_low_speed) * func_abs(Servo.output_val)) * 0.0025;

    // �Ż��������ж�
    if(erro[0] < 3 && erro[1] < 4 && erro[2] < 3 && erro[3] < 3 && erro[4] < 3)
    {
        cnt++;
        
        if(cnt > 15) 
        {

            Speed.target_val = straight_high_Speed;   
            Normals_flag = 2;           
        }
        else if(cnt > 3)
        {
            BUZZ_time = 1;
            Normals_flag = 1;
            Speed.target_val += straight_acc;
        }
    }  
    else 
    {
                    
        Normals_flag = 0;
        cnt = 0;
    }

    // �����ٶ�
    UpdateSpeed(Element_go, Element_go_speed);
    UpdateSpeed(Element_go_1, Element_go_1_speed);
}


void Normals_erro()
{
    static uint8 cnt = 0;
    //uint8 i;
     if((CCD1.find_R == 'N' || CCD1.find_L == 'N')&&((CCD2.find_R == 'Y' || CCD2.find_L == 'Y')))
    {
        cnt++;
    }
    else cnt = 0;
    
     if(cnt > 10 && (func_abs(CCD2.centres - CCD1.centres) < 12)&& CCD2.wides < 40) //10 12
    {Servo.ek  = (CCD2.centres - Center ); }
    else {Servo.ek  = CCD1.centres - Center;}
}
void Normals_Handle()/*����״̬����*/
{
    Normals_erro();
    Normals_Speed();
    if(zebra.Length < lenght)is_Zebra();//�������ж�
    if(ramps.num && ramps.Length < lenght)is_Ramps();//б���ж�
    if(LRing.num && LRing.Length < lenght&& ring_seq[ ring_num] == 0)is_LRING();//���ж�
    if(RRing.num && RRing.Length < lenght&& ring_seq[ ring_num] == 1 )is_RRING();//�һ��ж�
   // is_Handl();/*�ϰ��ж�*/
    RGBL = 0 ;
}


void Stops_Handle()//����ǰ״̬
{  
    uint8 i = 0;
    Servo.ek  = 0;
    //Speed.target_val = 0;
   
    //�������ֵ
    if(UI_mode)
    {
        MAX_1 = 0;
        MAX_2 = 0;
        for(i = 0 ; i < 128; i++)
        {
            if(MAX_1 < CCD1.ccd_data[i])MAX_1 = CCD1.ccd_data[i];
            if(MAX_2 < CCD2.ccd_data[i])MAX_2 = CCD2.ccd_data[i];
        }
        //����ڰ׵�
        //mean_1 = Mean_Val((uint8 *)&CCD1.normalized_data, 10, 118);

        //�������ֵ
        threshold_1  =  Max_SOD((uint8 *)&CCD1.normalized_data, 20, 108);
        threshold_2  =  Max_SOD((uint8 *)&CCD2.normalized_data, 20, 108);
    }
    

    ESC_out(esc_pwm_value);
}
//Բ�� ʮ��ͨ������������Ԫ�ر�־
//�µ�ͨ��ʱ������

//Ԫ�ش���
void Element_Handle()
{
    CCD1.centres = ((CCD1.left_col + CCD1.right_col + 1) >> 1);
    CCD2.centres = ((CCD2.left_col + CCD2.right_col + 1) >> 1);
    
    

    CCD1.wides = (uint8)(CCD1.right_col - CCD1.left_col);
    CCD2.wides = (uint8)(CCD2.right_col - CCD2.left_col);

    switch(Car_Mode)
    {
    case Normals:
        Normals_Handle();
        break;
    case Stops:
        Stops_Handle();
        break;
    case Ramps:
        Ramps_Handle();
        break;
    case LRING:
        LRING_Handle();
        break;
    case RRING:
        RRING_Handle();
        break;
    case Zebra:
        Zebra_Handle();
        break;
    default:
        Car_Mode = Normals;
        break;
    }
  Push_And_Pull(CCD1.wide, 4,  CCD1.wides);//����CCD1����
  Push_And_Pull(CCD2.wide, 4,  CCD2.wides);//����CCD2����
//    Push_And_Pull(CCD1.right, 4,  CCD1.right_col);//����CCD1�ұ߽�
//    Push_And_Pull(CCD1.left, 4,  CCD1.left_col);//����CCD1��߽�
//    
//    Push_And_Pull(CCD2.right, 4,  CCD2.right_col);//����CCD2�ұ߽�
//    Push_And_Pull(CCD2.left, 4,  CCD2.left_col);//����CCD2��߽�

}
