#include "A_Servo.h"
turn Servo = {0};


void Out_Ser(uint16 ser_pwm)
{
    ser_pwm =  func_limit_ab(ser_pwm, SERVO_R, SERVO_L);
    pwm_duty(SERVO, ser_pwm);
}


/*------------------------------------------------------------------------------------------------------
����    ����SteerPID_Realizeλ��ʽ
����    �ܡ����PID
����    ����offset ƫ��
���� �� ֵ����
--------------------------------------------------------------------------------------------------------*/
void SteerPID_Realize(void)
{
    float P_PID ,D_PID ;
    float erro;
    Servo.ek1[2] = Servo.ek1[1];
    Servo.ek1[1] = Servo.ek1[0];
    Servo.ek1[0] = 
           (Servo.ek * 0.8f) 
            +
           (Servo.ek1[0] * 0.1f) 
            +
           (Servo.ek1[1]* 0.07f) 
            +
           (Servo.ek1[2] * 0.03f);
     if(Car_Mode == RRING || (Car_Mode == LRING))
    {
        Servo.PID[P] = 15.8; //14.8
        Servo.PID[D] = 20;
        Servo.PID[IMU_D] = 0;
    }
    else if(Car_Mode == Ramps)
    {
        Servo.PID[P] = 15.2; 
        Servo.PID[D] = 12;
    }
    else
    {
        
        if(Normals_flag == 1)//���ֱ��
        {
            Servo.PID[P] = 17; 
            Servo.PID[D] = 18; 
        }
        else if(Normals_flag == 2)// ��ֱ��
        {
            Servo.PID[P] = 16;  
            Servo.PID[D] = 20;   
        }
        else 
        {
            erro = func_abs(Servo.ek1[0]);
          Servo.PID[P] = 18 + erro * Servo.ek1[0] / 1500;
          Servo.PID[D] = 15 + erro / 30;            
        }
                   
     
        Servo.PID[IMU_D] = 0;
    }
    P_PID = Servo.PID[P] * Servo.ek1[0];
    D_PID = Servo.PID[D] * (Servo.ek1[0] - Servo.ek1[2]);
   /* IMU_PID = Servo.PID[IMU_D] * IMUdata.YawVelocity; */
    
     
    Servo.output_val  = (int16)( P_PID  + D_PID /*- IMU_PID*/);
    Servo. output_val =  (Servo.output_val_last + 9 * Servo. output_val) * 0.1;
    
    Servo. output_val = func_limit_ab(Servo. output_val, -500, 500);
    Servo.output_val_last_last = Servo.output_val_last;
    Servo.output_val_last = Servo. output_val;
}
//void SteerPID_Realize(void)
//{
//    float P_PID ,D_PID;
//    float kp = 0,erro ;
//    Servo.ek1[2] = Servo.ek1[1];
//    Servo.ek1[1] = Servo.ek1[0];
//    Servo.ek1[0] = 
//           (Servo.ek * 0.8f) 
//            +
//           (Servo.ek1[0] * 0.1f) 
//            +
//           (Servo.ek1[1]* 0.07f) 
//            +
//           (Servo.ek1[2] * 0.03f);
//     if(Car_Mode == RRING || (Car_Mode == LRING))
//    {
//        Servo.PID[P] = 15.8; 
//        Servo.PID[T] = 1200;
//        Servo.PID[D] = 20;
//    }
//    else
//    {
//        erro = func_abs(Servo.ek1[0]);
//        if(erro < 9)Servo.PID[P] = 11;  
//        else if(erro < 10)Servo.PID[P] = 17.5f;
//        else if(erro < 13)Servo.PID[P] = 17.0f;
//        else if(erro < 15)Servo.PID[P] = 17.5f;
//        else if(erro < 17)Servo.PID[P] = 17.65f;
//        else if(erro < 18)Servo.PID[P] = 17.7f;
//        else if(erro < 19)Servo.PID[P] = 17.73f;
//        else  if(erro < 20)Servo.PID[P] = 17.75f; 
//        else   Servo.PID[P] = 17.77; 
//        Servo.PID[T] = 2000;
//        Servo.PID[D] = 15 + erro / 30;
//    }
//    
////w'w'w'w'w'w'w'w'w'w'w
//    kp = Servo.ek1[0] * Servo.ek1[0] / Servo.PID[T] +  Servo.PID[P];
//    P_PID = kp * Servo.ek1[0];
//    D_PID = Servo.PID[D] * (Servo.ek1[0] - Servo.ek1[2]);
//    //D_PID = func_limit_ab(D_PID, -100, 100);
//     
//    Servo.output_val  = (int16)( P_PID  + D_PID );
//    Servo. output_val = 0.1 * Servo.output_val_last + 0.9 * Servo. output_val;
//    Servo. output_val = func_limit_ab(Servo. output_val, -500, 500);
//    Servo.output_val_last = Servo. output_val;
//}