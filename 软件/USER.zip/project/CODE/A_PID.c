#include "A_PID.h"
#define FILTER_Turn_0 0.8f
#define FILTER_Turn_1 0.1f
#define FILTER_Turn_2 0.07f
#define FILTER_Turn_3 0.03f
MY_turn price = {0};

void pid_clear()
{
    /***************************************ת��*******************************/

    price.Pre1_Error[0] = 0;
    price.Pre1_Error[1] = 0;
    price.Pre1_Error[2] = 0;
    price.Pre1_Error[3] = 0;
    price.ek = 0;
    price.ek1 = 0,

     price.in_ek = 0;
    price.in_ek1 = 0,
    price.in_ek2 = 0;

    price.output_val = 0;

    price.target_val = 0;
    price.target_val_last = 0;

    price.COUNTS = 0;

}
/****************************************************************
�������ܣ�pid������ʼ��
��ڲ�����NULL
����  ֵ��NULL
****************************************************************/
 void mypid_init()
{
    pid_clear();


    /***************************************ת��*******************************/
    //�ڻ�
    price.kp = 2; //����//5
    price.kd = 1; //΢��//2

    //�⻷
    price.in_kp = 0.1; // adc����Ȩֵ//3.45 2.95

    //����
    price.maxOutput = 3000;

}
void DerectError_Get(MY_turn *pid) //�⻷
{

    pid->target_val = Servo.output_val_last_last + Servo.output_val_last + Servo.output_val;

    pid->target_val_last = pid->target_val;
}


void Direction_out(MY_turn *pid)//�ڻ�
{
    //pid->target_val = 0; //������仰����ʾת��ֻ���ڻ����⻷���Ϊ0
    float GYRO_Z = func_limit(IMUdata.GYRO_Z,1000);
    //pid->target_val = 3 * Servo.output_val;
    pid->ek = pid->target_val - GYRO_Z * pid->in_kp;

    pid->output_val = pid->kp * pid->ek + pid->kd * (pid->ek - pid->ek1);

    pid->ek1 = pid->ek;  //�����ϴ����

    pid-> Pre1_Error[3] = pid->Pre1_Error[2];
    pid-> Pre1_Error[2] = pid->Pre1_Error[1];
    pid-> Pre1_Error[1] = pid->Pre1_Error[0];
    pid-> Pre1_Error[0] = pid->output_val;

    pid->output_val =   (pid-> Pre1_Error[0] * FILTER_Turn_0) +
                        (pid-> Pre1_Error[1] * FILTER_Turn_1) +
                        (pid-> Pre1_Error[2] * FILTER_Turn_2) +
                        (pid-> Pre1_Error[3] * FILTER_Turn_3) ;
    pid->output_val_last = pid->output_val;

    pid->output_val = func_limit(pid->output_val, price.maxOutput); //ת�����Ʒ���
}

void DifferControl( MY_turn *pid)
{
    if (pid->COUNTS == 3)
    {
        pid->COUNTS = 0;
        DerectError_Get(pid);
    }
    pid->COUNTS++;
    pid->target_val = pid->target_val_last + (pid->target_val - pid->target_val_last) * pid->COUNTS / 3;
    Direction_out(pid);
}