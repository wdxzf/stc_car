#ifndef __A_VOFA_H
#define __A_VOFA_H

#include "headfile.h"

    void seekfree_Init(void);
    void Image_Send(uint16 *data1, uint16 *data2); // ����ͼ��
    void Image_Send1(uint8 *data1, uint8 *data2);

extern  uint8 y3_boundary[128];
#endif