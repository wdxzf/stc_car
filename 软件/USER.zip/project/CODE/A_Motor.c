#include "A_Motor.h"

PID Speed = {0};
Step Step1 = {0};

float lenght = 0;

void ctimer_clean(void)
{
    // ��λ��ʱ��3
    T4T3M &= ~0x08;  // �رն�ʱ��3
    T3L = 0;
    T3H = 0;
    T4T3M |= 0x08;   // ����������ʱ��3
    
    // ��λ��ʱ��0
    TR0 = 0;         // �رն�ʱ��0
    TL0 = 0;
    TH0 = 0;
    TR0 = 1;         // ����������ʱ��0
}
void Get_Speed()
{
    static int16 previousSpeed_L[10] = {0}, previousSpeed_R[10] = {0};
    float lenght_1;
    int16 averageSpeed = 0;
    int16 speed_L = ((uint16)T3H << 8) | (uint8)T3L;
    int16 speed_R = ((uint16)TH0 << 8) | (uint8)TL0;
    uint8 i;
    
     ctimer_clean();

    if (SPEEDL_DIR != 1) speed_L = -speed_L;
    if (SPEEDR_DIR == 1) speed_R = -speed_R;

    for (i = 9; i > 0; i--)
    {
        previousSpeed_L[i] = previousSpeed_L[i - 1];
        previousSpeed_R[i] = previousSpeed_R[i - 1];
        averageSpeed += (previousSpeed_L[i] + previousSpeed_R[i]);
    }

    previousSpeed_L[0] = speed_L;
    previousSpeed_R[0] = speed_R;
    averageSpeed += (speed_L + speed_R);
    
    
    Speed.now = (int16)((averageSpeed + 3) >> 3);//��������
    lenght_1 = Speed.now * PulseMPS  * dt ;
    
    Step1.Lenth = (Step1.flag & 0x01) ? (Step1.Lenth + lenght_1) : 0;

    lenght += lenght_1;//1��1cm
    
    
}



/*************************************************�������***************************************************/


static void Motor_L(int32 dutyL)//�������ת��
{
    if(dutyL > 0)//��ת
    {
        DIR_L = 1;
        pwm_duty(PWM_L, dutyL + Dead_L);
    }
    else  //��ת
    {
        DIR_L = 0;
        pwm_duty(PWM_L, -dutyL + Dead_L);
    }
}

static void Motor_R(int32 dutyR)//�������ת��
{
    if(dutyR > 0)//��ת
    {
        DIR_R = 0;
        pwm_duty(PWM_R, dutyR + Dead_R);
    }
    else  //��ת
    {
        DIR_R = 1;
        pwm_duty(PWM_R, -dutyR + Dead_R);
    }
}

void out_pwm(int32 dutyL, int32 dutyR)//�� ��
{
    dutyR = func_limit_ab(dutyR, -9400, 9400);
    dutyL = func_limit_ab(dutyL, -9400, 9400);

    Motor_R(dutyR);
    Motor_L(dutyL);
}


void ESC_out(uint16 pwm_val)//��ѹ
{
    static float esc_pwm_value_last = 0; // ��̬�������洢��һ�ε�PWMֵ
    int16 difference;
    
    if (SW3)  pwm_val = 0;
   
    if ((uint16)esc_pwm_value_last != pwm_val)
    {
        difference = pwm_val - (uint16)esc_pwm_value_last;  // �����ֵ
        esc_pwm_value_last += difference *  0.004;        // ���� pwm_value_last
        pwm_duty(ESC_PWMR, (uint32)esc_pwm_value_last);             // �Ҳ�PWM
        pwm_duty(ESC_PWML, (uint32)esc_pwm_value_last);             // ���PWM
    }
}
void PID_Motor_Init(void)
{
    Speed.kp = 10;
    Speed.ki = 0.23;
}

//uint16 motor_Bang[5] = {6000, 5000, 4000, 3000, 2000};

void PID_motor(PID *pid)
{
    pid->ek1 = pid->ek;

    // ���㵱ǰ���

    pid->ek = pid->target_val - pid->now;
    if(pid->ek > 50)
    {
        if(pid->ek > 300)pid->bang = 280;
        if(pid->ek > 200)pid->bang = 190;
        else if(pid->ek > 80)pid->bang = 45;
        else if(pid->ek > 70) pid->bang = 30;
        else  pid->bang = 21;
    }
    else if(pid->ek < -50)
    {
        if(pid->ek < -300)pid->bang = -400;
        if(pid->ek < -200)pid->bang = -300;
        else if(pid->ek < -80)pid->bang = -45;
        else if(pid->ek < -70) pid->bang = -30;
        else pid->bang = -21;
    }
    else 
    {
        pid->bang = 0;
    }
    // �����ϴ����

    Speed.kp = 17;
    Speed.ki = 0.255; 

        pid->pid_delta = (pid->kp * (pid->ek - pid->ek1) + pid->ki * pid->ek);

    
    
        pid->output_val += (int16) pid->pid_delta;
        pid->output_val = (int16)(0.8* pid->output_val + 0.2 * pid->output_val_last) + pid->bang;
        pid->output_val = func_limit_ab(pid->output_val,-9000,9000);
        pid->output_val_last = pid->output_val;


}

void motor_turn()
{
    float motor_turn_P = 0.001;
    float turn_val = 0;

    if(zebra.flag == 1)
    {
        out_pwm(-2000, -2000);
        if(Speed.now < 8)
        {
            zebra.num--;
            zebra.flag++;
        }
    }
    else if(zebra.flag == 2||Car_Mode == Stops)
    {
        out_pwm(0, 0);
    }
    else
    {
//        turn_val = motor_turn_P * func_abs(Servo.output_val) / (2 + motor_turn_P * func_abs(Servo.output_val));
//        if(Servo.output_val < 0) //��ת
//        out_pwm(Speed.output_val- turn_val * Speed.output_val , Speed.output_val + turn_val * Speed.output_val);
//        else out_pwm(Speed.output_val + turn_val * Speed.output_val, Speed.output_val - turn_val * Speed.output_val);
        out_pwm(Speed.output_val, Speed.output_val );
        seekfree_assistant_oscilloscope_data.dat[3] = turn_val * Speed.output_val;
        seekfree_assistant_oscilloscope_data.dat[4] = Speed.output_val;
    }

    // �������������Ϣ����ѡ��
    // seekfree_assistant_oscilloscope_data.dat[1] = turn_val * Speed.output_val;
}


/*************************************************�������***************************************************/
/***********************************************************
	*	�������ƣ�motor_soft_start(int speed_normal)
	*	����˵�����������
	*	����������int speed_normal
	*	�������أ�start_over_sign
	*	����˵����
	*	�޸����ڣ�2019-04-26
***********************************************************/
//char motor_soft_start(int speed_normal)
//{
//	static char start_over_sign=0;        //�������𶯽�����־
//	int normal_speed_pwm;
//	if(start_over_sign == 0)            //������𶯹��̻�û�н���
//	{
//		//normal_speed_pwm = (uint32)(1.67 * (float)(speed_normal) + 62.24);
//		normal_speed_pwm = (int)(187 * (speed_normal) + 700);
//		if((Speed_L < (speed_normal - 5)) || (Speed_R < (speed_normal - 5)))
//		{
//			Motor_Run(Motor_L,normal_speed_pwm);
//			Motor_Run(Motor_R,normal_speed_pwm);
//		}
//		else                            //������𶯽���
//		{
//			start_over_sign = 1;
//		}
//	}
//
//	return start_over_sign;
//}

//void car_stall_protect(void) {//�����ת����
//  if (SystemData.GO_OK) {
//    ++cnt;
//    if (cnt > 2 && SystemData.SpeedData.nowspeed < 30)
//      SystemData.Stop = 1;
//    if (SystemData.SpeedData.nowspeed > 30)
//      cnt = 0;
//  }
//}



#if 0
void FeedforwardController(FFCTypeDef_t *pid)
{
    float FFCa = 1.0f, FFCb = 1.0f;

    pid->FOutput = FFCa * (pid->Rin - pid->LastRin) + FFCb * (pid->Rin - 2 * pid->LastRin + pid->PerrRin);

    pid->PerrRin= pid->LastRin;
    pid->LastRin= pid->Rin;
}
#endif