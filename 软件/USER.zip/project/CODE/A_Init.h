#ifndef __A_INIT_H
#define __A_INIT_H
#include "headfile.h"

#define TIM4_ISR  4  //�ж�ʱ��
#define dt        0.04//TIM4_ISR *1.0 / 100

void Car_Init(void);
void Car_Launch(void);

extern volatile uint8 uwTick; 
extern uint16 BUZZ_time;
void BUZZ_ON(void);
#endif
