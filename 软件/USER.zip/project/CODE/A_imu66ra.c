#include "A_imu66ra.h"

IMU660RA IMUdata = {0};


void ICM_OneOrderFilter(void)
{
    float filtered_GYRO_Z;
    
    //��ȡ���ٶ�
    /*if(Car_Mode == Ramps||Car_Mode == LRING||Car_Mode == RRING)*/imu660ra_get_gyro();
    if(Car_Mode == Ramps)IMUdata.Pitch = (8U * imu660ra_gyro_y + 2U * IMUdata.Pitch) *0.1f;
     filtered_GYRO_Z = (imu660ra_gyro_z > 0) 
                        ? 
                       (imu660ra_gyro_z - IMUdata.YawVelocity_offset_1) 
                        : 
                       (imu660ra_gyro_z - IMUdata.YawVelocity_offset_2);
    
    
     IMUdata.GYRO_Z = (2 * IMUdata.GYRO_Z + 8 * filtered_GYRO_Z) * 0.1f;
     IMUdata.YawVelocity = IMUdata.GYRO_Z * 0.00625f;
    
    
   IMUdata.Yaw = (IMUdata.flag & 0x01) == 0 ? 0 : IMUdata.Yaw + (IMUdata.YawVelocity * dt);

  
}


void GyroOffsets(uint16 count_g)
{

    int16 y_1 = 0, y_2 = 0;
    uint16 count1 = 0, count2 = 0;
    uint16 i;
    for (i = 0; i < count_g; i++)
    {
        imu660ra_get_gyro();
        delay_ms(1);
        if (imu660ra_gyro_z > 0)
        {
            y_1 += imu660ra_gyro_z;
            count1++;
        }
        else
        {
            y_2 += imu660ra_gyro_z;
            count2++;
        }
    }

    IMUdata.YawVelocity_offset_1 = (float)y_1 / count1;
    IMUdata.YawVelocity_offset_2 = (float)y_2 / count2;
}