#include "A_Key.h"
float Disp_Str[10] = {0};

//135*240//һ������8λ   �� 30���ַ� ��7��

uint8 step_num = 7; //����ֵ 0.1 1 10 50 100 12
float step[12] = {-1000, -100, -50, -10, -1, -0.1, 0.1, 1, 10, 50, 100, 1000};
//��������
uint16 MAX_1 = 0, MAX_2 = 0;//CCD���ֵ
uint8 threshold_1 = 0, threshold_2 = 0; //CCD��ֵ
uint8 UI_mode = 0; //�Ƿ���ֵ
uint8 ucKey_Up = 0; //����̧��

uint16 esc_pwm_value = 5800; // ȫ�ֱ��������ڴ洢��ǰ��PWMֵ

//��������
void UI_Disp(void);

unsigned char Mod[7][9] //ģʽ����
=
{
    "Normals",
    "Ramps",
    "LRING",
    "RRING",
    "Zebra",
    "Handl",
    "Stops",
};

unsigned char ui_page0[8][14]//һ���˵�����  //���� 20 ����ĸ
=
{
    " CCD   ",   //������ֵ
    " monitor ", //��ؽ���
    " RING ", //Բ������
    " Zebra   ",  //�����߽���
    " Ramps ",  //�µ�����
    " Normals ",  //��������
    "   ", //��Բ������
    "UI_1" //��ʾһ���˵�
};

unsigned char ui_CCD[8][14]//һ���˵�����  //���� 20 ����ĸ
=
{
    " is: ", // ֵ
    " thresh_1", //�׵�
    " thresh_2", //�ڵ�
    " ",
    " ", //���ֵ
    " CCD1_M",
    " CCD2_M",  //���ֵ

    "UI_CCD"
};


unsigned char ui_RING[8][14]//�󻷽���
=
{
    " num: ",
    " lengh: ",
    " v_in: ",//ԤԲ�� ��Բ��
    " v_on: ", //Բ����
    " v_out: ",//��Բ��
    " v_c ", //������
    " ring:",
    "UI_RING"
};
unsigned char ui_Zebra[8][14]//�����߽���
=
{
   
    " lengh: ",
    " cnt: ",
    "  ",
    " Wind: ",
    "  ",
    " ", //���ֵ 
    "",
    "UI_Zebra" //��ʾһ���˵�
};

unsigned char ui_Ramps[8][14]//�µ�����
=
{
    " num: ",
    " lengh: ",
    " v_read: ",//׼������
    " v_up: ", //����
    " v_down ", //����
    " ",
    " ",
    "UI_Ramps" //��ʾһ���˵�
};

unsigned char ui_Normals[8][14]//��������
=
{
    " V:",
    " V_H",
    " go: ",//��Ԫ�ؼ���
    " go1: ", // ����ֵ
    " ",
    " ",
    " ",
    "UI_Normals" //��ʾһ���˵�
};
UI_CLASS ui =
{
    &UI_Disp,
    {0, 0, 0, 0}, 0, -1
};

static uint8 Key_Scan()
{

    if(!KEY1) return 1;
    if(!KEY2) return 2;
    if(!KEY3) return 3;
    if(!KEY4) return 4;
    if(!KEY5) return 5;
    if(!KEY6) return 6;
    if(!KEY7) return 7;
    return 0;
}

static void UI_DispUIStrings(uint8 strings[8][14])//��ʾ��ͷ
{
    uint8 i;
    for (i = 0; i < 7; i++)
    {
        strings[i][0] = (i == ui.cursor[ui.page]) ? '>' : ' ';
        ips114_showstr(0, i, strings[i]);
    }
    ips114_showstr(22 * 8, 7, strings[7]);
}
void UI_Disp(void)
{
    uint8 i;
    ips114_showstr(64, 7, "Step:");
    ips114_showfloat(104, 7, step[step_num], 4, 1);

    Disp_Str[5] = Servo.ek;
    Disp_Str[6] = lenght;
    switch(ui.page)
    {

    case 0:
        if(ui.enter == -1)//һ���˵�
        {
            UI_DispUIStrings(ui_page0);
            ips114_showstr(160, 0, Mod[Car_Mode]);
            if(ucKey_Up == 7)
            {
                if(SW1) Car_Mode = Normals;
            }
        }
        else
        {
            if(ui.enter == 0)//������ֵ����
            {
                UI_DispUIStrings(ui_CCD);

                ips114_showuint8(9 * 8, 1, CCD1.threshold);
                ips114_showuint8(9 * 8, 2, CCD2.threshold);
                ips114_showuint8(18 * 8, 1, threshold_1);
                ips114_showuint8(18 * 8, 2, threshold_2);

                ips114_showuint8(9 * 8, 0, UI_mode);


                ips114_showuint16(9 * 8, 5, CCD1.max_value);
                ips114_showuint16(9 * 8, 6, CCD2.max_value);
                ips114_showuint16(18 * 8, 5, MAX_1);
                ips114_showuint16(18 * 8, 6, MAX_2);

                if(ucKey_Up == 6)
                {
                    
                    if(ui.cursor[ui.page] == 0) UI_mode = !UI_mode;
                    else if(ui.cursor[ui.page] == 1){CCD1.threshold += step[step_num];}
                    else if(ui.cursor[ui.page] == 2){CCD2.threshold += step[step_num];}
                    else if(ui.cursor[ui.page] == 5){CCD1.max_value += step[step_num];}
                    else if(ui.cursor[ui.page] == 6){CCD2.max_value += step[step_num];}

                }
            }
            if(ui.enter == 1)//���ӽ���
            {
                ips114_showfloat(0, 0, Disp_Str[0], 4, 2);
                ips114_showfloat(0, 1, Disp_Str[1], 4, 2);
                ips114_showfloat(0, 2, Disp_Str[2], 4, 2);
                ips114_showfloat(0, 3, Disp_Str[3], 4, 2);
                ips114_showfloat(0, 4, Disp_Str[4], 4, 2);
                ips114_showfloat(0, 5, Disp_Str[5], 4, 2);
                ips114_showfloat(0, 6, Disp_Str[6], 4, 2);


                ips114_showstr(8 * 8, 0, "  CCD1");
                ips114_showchar(8 * 8, 2 * 16, CCD1.find_L);
                ips114_showuint8(8 * 8, 2, CCD1.left_col);
                ips114_showuint8(8 * 8, 3, CCD1.centres);
                ips114_showchar(8 * 8, 4 * 16, CCD1.find_R);
                ips114_showuint8(8 * 8, 4, CCD1.right_col);
                ips114_showuint8(8 * 8, 5, CCD1.wides);
                ips114_showint16(8 * 8, 6, CCD1.centres - 64);


                ips114_showstr(18 * 8, 0, "  CCD2");
                ips114_showchar(18 * 8, 2 * 16, CCD2.find_L);
                ips114_showuint8(18 * 8, 2, CCD2.left_col);
                ips114_showuint8(18 * 8, 3, CCD2.centres);
                ips114_showchar(18 * 8, 4 * 16, CCD2.find_R);
                ips114_showuint8(18 * 8, 4, CCD2.right_col);
                ips114_showuint8(18 * 8, 5, CCD2.wides);
                ips114_showint16(18 * 8, 6, CCD2.centres - 64);
            }
            else if(ui.enter == 2)//������
            {
                UI_DispUIStrings(ui_RING);

                ips114_showuint8(9 * 8, 0, LRing.num);
                ips114_showint32(9 * 8, 1, LRing.Length, 5);

                ips114_showuint16(9 * 8, 2, Speed_target_val_LRING[0]);
                ips114_showuint16(9 * 8, 3, Speed_target_val_LRING[1]);
                ips114_showuint16(9 * 8, 4, Speed_target_val_LRING[2]);
                ips114_showuint16(9 * 8, 5, Speed_target_val_LRING[3]);
                
                ips114_showuint8(19 * 8, 0, RRing.num);
                ips114_showint32(19 * 8, 1, RRing.Length, 5);

                ips114_showuint16(19 * 8, 2, Speed_target_val_RRING[0]);
                ips114_showuint16(19 * 8, 3, Speed_target_val_RRING[1]);
                ips114_showuint16(19 * 8, 4, Speed_target_val_RRING[2]);
                ips114_showuint16(19 * 8, 5, Speed_target_val_RRING[3]);
                
                for (i = 0; i < 8; i++)
                {
                    ring_seq[i] = (RSeq >> (7 - i)) & 1;
                    ips114_showchar((uint16)(7 * 8 + (8 * (i + 1))), (uint16)(6 * 16), (int8)('0' + ring_seq[i]));
                }

                ips114_showuint8(18 * 8, 6, RSeq);
                if(ucKey_Up == 7)
                {
                    
                    if(ui.cursor[ui.page] == 0)
                    {
                        LRing.num                   += step[step_num];
                        LRing.num                   =  func_limit_ab(LRing.num, 0, 10);
                    }
                    else if(ui.cursor[ui.page] == 1){LRing.Length += step[step_num];}
                    else if(ui.cursor[ui.page] == 2){Speed_target_val_LRING[0] += step[step_num];}
                    else if(ui.cursor[ui.page] == 3){Speed_target_val_LRING[1] += step[step_num];}
                    else if(ui.cursor[ui.page] == 4){Speed_target_val_LRING[2] += step[step_num];}
                    else if(ui.cursor[ui.page] == 5){Speed_target_val_LRING[3] += step[step_num];}
                    else if(ui.cursor[ui.page] == 6){RSeq += step[step_num];                     }
                }
                else if(ucKey_Up == 6)
                {
                    
                    if(ui.cursor[ui.page] == 0)
                    {
                        RRing.num    += step[step_num];
                        RRing.num = func_limit_ab(RRing.num, 0, 10);
                       
                    }
                    else if(ui.cursor[ui.page] == 1){RRing.Length += step[step_num];}
                    else if(ui.cursor[ui.page] == 2){Speed_target_val_RRING[0] += step[step_num];}
                    else if(ui.cursor[ui.page] == 3){Speed_target_val_RRING[1] += step[step_num];}
                    else if(ui.cursor[ui.page] == 4){Speed_target_val_RRING[2] += step[step_num];}
                    else if(ui.cursor[ui.page] == 5){Speed_target_val_RRING[3] += step[step_num];}
                }
            }
            else if(ui.enter == 3)//�����߽���
            {
                UI_DispUIStrings(ui_Zebra);


                ips114_showint32(10 * 8, 0, zebra.Length, 5);

                ips114_showuint8(10 * 8, 1, Zebra_cnt);

                ips114_showuint16(10 * 8, 3, esc_pwm_value);

                if(ucKey_Up == 7)
                {
                    if(ui.cursor[ui.page] == 0){zebra.Length += step[step_num];}
                    else if(ui.cursor[ui.page] == 1){Zebra_cnt += step[step_num];}
                    else if(ui.cursor[ui.page] == 3){esc_pwm_value += step[step_num];}
                }

            }
            else if(ui.enter == 4)//�µ�����
            {
                UI_DispUIStrings(ui_Ramps);

                ips114_showuint8(10 * 8, 0, ramps.num);
                ips114_showint32(10 * 8, 1, ramps.Length, 5);

                ips114_showuint16(10 * 8, 2, Speed_target_val_Ramps[0]);
                ips114_showuint16(10 * 8, 3, Speed_target_val_Ramps[1]);
                ips114_showuint16(10 * 8, 4, Speed_target_val_Ramps[2]);

                if(ucKey_Up == 7)
                {
                    if(ui.cursor[ui.page] == 0)
                    {
                        ramps.num    += step[step_num];
                        ramps.num = func_limit_ab(ramps.num, 0, 10);
                    }
                    else if(ui.cursor[ui.page] == 1)ramps.Length += step[step_num];
                    else if(ui.cursor[ui.page] == 2)Speed_target_val_Ramps[0] += step[step_num];
                    else if(ui.cursor[ui.page] == 3)Speed_target_val_Ramps[1] += step[step_num];
                    else if(ui.cursor[ui.page] == 4)Speed_target_val_Ramps[2] += step[step_num];
                }

            }
            else if(ui.enter == 5) //����ģʽ
            {
                UI_DispUIStrings(ui_Normals);

                ips114_showuint16(8 * 8, 0, Normals_high_Speed);
                ips114_showuint16(18 * 8, 0, Normals_low_speed);
                
                ips114_showuint16(8 * 8, 1, straight_high_Speed);
                ips114_showuint16(18 * 8, 1, straight_acc);
                
                ips114_showstr(72, 2, Mod[Element_go]);
                ips114_showint16(18 * 8, 2, Element_go_speed);

                ips114_showstr(72, 3, Mod[Element_go_1]);
                ips114_showint16(18 * 8, 3, Element_go_1_speed);


                if(ucKey_Up == 7)
                {
                    if(ui.cursor[ui.page] == 0)     Normals_high_Speed  += step[step_num];
                    else if(ui.cursor[ui.page] == 1)straight_high_Speed += step[step_num];
                    else if(ui.cursor[ui.page] == 2)
                    {
                        Element_go  += step[step_num];
                        if(Element_go < 1)Element_go = 4;
                        if(Element_go > 4)Element_go = 1;
                    }
                     else if(ui.cursor[ui.page] == 3)
                    {
                        Element_go_1  +=    step[step_num];
                        if(Element_go_1 < 1)Element_go_1 = 4;
                        if(Element_go_1 > 4)Element_go_1 = 1;
                    }
                }
                else if(ucKey_Up == 6)
                {
                    if(ui.cursor[ui.page] == 0)     Normals_low_speed  += step[step_num];
                    else if(ui.cursor[ui.page] == 1)straight_acc += step[step_num];
                    else if(ui.cursor[ui.page] == 2)Element_go_speed  += step[step_num];
                    else if(ui.cursor[ui.page] == 3)Element_go_1_speed  += step[step_num];
                }
            }
        }
        break;
    case 1:
        break;
    case 2:
        break;
    case 3:
        break;
    }
}
void Key_Proc(void)
{
    static uint8 ucKey_Old = 0;
    uint8 ucKey_Val = 0;

    ucKey_Val  = Key_Scan();
    ucKey_Up = ~ucKey_Val & (ucKey_Old ^ ucKey_Val);
    ucKey_Old  = ucKey_Val;

    if(ucKey_Up)
    {
        BUZZ_time = 3;

        switch(ucKey_Up)
        {

        case 2: //�� ��
            if(ui.enter >= 0)//�˳������˵�
            {
                ui.cursor[ui.page] = ui.enter;
                ui.enter = -1;
                ips114_clear(Black);
            }
            else//��������˵�
            {
                ui.enter = ui.cursor[ui.page];
                ui.cursor[ui.page] = 0;
                ips114_clear(Black);
            }
            UI_mode = 0;
            break;
        case 3: //�� ��
            ui.cursor[ui.page]--;
            if (ui.cursor[ui.page] < 0)ui.cursor[ui.page] = 6;
            break;
        case 5: //����
            ui.cursor[ui.page]++;
            if (ui.cursor[ui.page] > 6) ui.cursor[ui.page] = 0;

            break;

        case 1: // �� ��
            step_num = (step_num + 1) % 12;//bu
            break;
        case 4: // �� ��
            step_num = (step_num + 11) % 12;
            break;

        }
    }

}
void EepromWrite(void)
{
    //������ֵ���� //0-6
    flash_buffer[0].uint8_type  =  CCD1.threshold;
    flash_buffer[1].uint8_type  =  CCD2.threshold;
    flash_buffer[2].uint8_type  =  RSeq;
    flash_buffer[3].uint16_type =  CCD1.max_value;
    flash_buffer[4].uint16_type =  CCD2.max_value;
    
    //�һ����� 7-13 
    flash_buffer[7].uint8_type  =  RRing.num; 
    flash_buffer[8].uint32_type =  RRing.Length;
    flash_buffer[9].int16_type  =  Speed_target_val_RRING[0];
    flash_buffer[10].int16_type =  Speed_target_val_RRING[1];
    flash_buffer[11].int16_type =  Speed_target_val_RRING[2];
    flash_buffer[12].int16_type =  Speed_target_val_RRING[3];
    
    //�󻷽��� - 20 
    flash_buffer[14].uint8_type  =  LRing.num;
    flash_buffer[15].uint32_type =  LRing.Length;
    flash_buffer[16].int16_type  =  Speed_target_val_LRING[0];
    flash_buffer[17].int16_type  =  Speed_target_val_LRING[1];
    flash_buffer[18].int16_type  =  Speed_target_val_LRING[2];
    flash_buffer[19].int16_type  =  Speed_target_val_LRING[3];
    
    //�����߽��� 21-27
    flash_buffer[21].uint32_type =  zebra.Length; 
    flash_buffer[22].uint8_type  =  Zebra_cnt;
    flash_buffer[23].uint16_type =  esc_pwm_value;
    
    //�µ����� 28-34
    flash_buffer[28].uint8_type  =  ramps.num;
    flash_buffer[29].uint32_type =  ramps.Length;
    flash_buffer[30].int16_type  =  Speed_target_val_Ramps[0];
    flash_buffer[31].int16_type  =  Speed_target_val_Ramps[1];
    flash_buffer[32].int16_type  =  Speed_target_val_Ramps[2];
    
    //����ģʽ 35-41
    
    flash_buffer[35].int16_type  = Normals_high_Speed;
    flash_buffer[36].int16_type  =  Normals_low_speed;
    flash_buffer[37].int16_type  = straight_high_Speed;
    flash_buffer[38].uint8_type  = Element_go;
    flash_buffer[39].int16_type  = Element_go_speed;
    flash_buffer[40].uint8_type  = Element_go_1;
    flash_buffer[41].int16_type  = Element_go_1_speed;
    flash_buffer[42].int16_type  = straight_acc;
    
 FLash_Write(flash_buffer, 0, 43);
}

void EepromRead(void)
{
    // �� Flash �ж�ȡ���ݵ�������
    FLash_Read(flash_buffer, 0, 43); // ��ȡ42��Ԫ�أ�������0��ʼ
    
    // ������ֵ���� // 0-6
    CCD1.threshold    = flash_buffer[0].uint8_type;
    CCD2.threshold    = flash_buffer[1].uint8_type;
    RSeq              = flash_buffer[2].uint8_type;
    CCD1.max_value    = flash_buffer[3].uint16_type;
    CCD2.max_value    = flash_buffer[4].uint16_type;

    // �һ����� 7-13
    RRing.num               = flash_buffer[7].uint8_type;
    RRing.Length            = flash_buffer[8].uint32_type;
    Speed_target_val_RRING[0] = flash_buffer[9].int16_type;
    Speed_target_val_RRING[1] = flash_buffer[10].int16_type;
    Speed_target_val_RRING[2] = flash_buffer[11].int16_type;
    Speed_target_val_RRING[3] = flash_buffer[12].int16_type;

    // �󻷽��� 14-20
    LRing.num               = flash_buffer[14].uint8_type;
    LRing.Length            = flash_buffer[15].uint32_type;
    Speed_target_val_LRING[0] = flash_buffer[16].int16_type;
    Speed_target_val_LRING[1] = flash_buffer[17].int16_type;
    Speed_target_val_LRING[2] = flash_buffer[18].int16_type;
    Speed_target_val_LRING[3] = flash_buffer[19].int16_type;


    // �����߽��� 21-27
    zebra.Length   = flash_buffer[21].uint32_type;
    Zebra_cnt      = flash_buffer[22].uint8_type;
    esc_pwm_value  = flash_buffer[23].uint16_type;

    // �µ����� 28-34
    ramps.num      = flash_buffer[28].uint8_type;
    ramps.Length      = flash_buffer[29].uint32_type;
    Speed_target_val_Ramps[0] = flash_buffer[30].int16_type;
    Speed_target_val_Ramps[1] = flash_buffer[31].int16_type;
    Speed_target_val_Ramps[2] = flash_buffer[32].int16_type;

    // ����ģʽ 35-42
    Normals_high_Speed   = flash_buffer[35].int16_type;
    Normals_low_speed    = flash_buffer[36].int16_type;
    straight_high_Speed  = flash_buffer[37].int16_type;
    Element_go           = flash_buffer[38].uint8_type;
    Element_go_speed     = flash_buffer[39].int16_type;
    Element_go_1         = flash_buffer[40].uint8_type;
    Element_go_1_speed   = flash_buffer[41].int16_type;
    straight_acc         = flash_buffer[42].int16_type;
}
