#ifndef _A_CCD_H
#define _A_CCD_H

#include "headfile.h"

#define Center              64 
#define SEARCH_IMAGE_W      128            //图像宽度           
#define CONTRASTSTOFFSET    4              //搜线对比偏移
#define SEARCHRANGE         6              //搜线半径

#define CCDWIde1            23             //CCD1宽度
#define CCDWIde2            15             //CCD2宽度

#define CCD_Offset          20             //暗电压

#define Col_Max      SEARCH_IMAGE_W - CONTRASTSTOFFSET - 1   //列最大值 127 - 差分
#define Col_Min      CONTRASTSTOFFSET                        //列最小值 差分


typedef struct 
{
    uint16 ccd_data[128];       // CCD 数据
    
    uint8 normalized_data[128]; // 归一化的 CCD 数据
    uint16 max_value;       // 最大值
     
    uint8 threshold; // 阈值
    uint8 centres;

    
    uint8  wides,
            wide[4];          //宽度记录
    uint8 left_col,      
          right_col;     // 右边界
    
    uint8 left[4],// 左边线记录
          right[4];//右边线记录
    
    //动态搜线点
    uint8 left_start_col, 
          left_end_col,
    
          right_start_col,
          right_end_col,
    //丢线标志      
                find_L,
                find_R;
    /*//丢线历史数据
                find_l_last[20],
                find_r_last[20];*/
}CCD;
void normalize(CCD *ccd);
void Find_Bothine(CCD *ccd);
extern void CCD_Init(void);

extern CCD CCD1, CCD2;
extern uint8 White_point,Black_point;                      
           
#endif